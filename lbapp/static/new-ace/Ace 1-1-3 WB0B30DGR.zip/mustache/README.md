You don't need Mustache files for your application.

I've used them to separate different sections of pages and layouts
to make it easier to figure out the structure and each pages's elements.

Otherwise you may have to dig through lots of static HTML code to figure out things.


Template files are inside *app/views* folder.
Refer to *app/views/layouts/default.mustache* file as a starting point
to figure out the general structure of HTML elements and sections. 

Please read the docs for more info.
